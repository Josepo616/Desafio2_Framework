document.addEventListener("DOMContentLoaded", function() {
    // Obtener la lista de películas cuando la página se carga
    fetch('/pelicula')
        .then(response => response.json())
        .then(data => {
            const peliculasList = document.getElementById('peliculas-list');
            peliculasList.innerHTML = '';
            data.forEach(pelicula => {
                const li = document.createElement('li');
                li.textContent = `${pelicula.titulo} - ${pelicula.director} - ${pelicula.año} - ${pelicula.genero} - ${pelicula.calificacion}`;
                const editButton = document.createElement('button');
                editButton.textContent = 'Editar';
                editButton.addEventListener('click', () => showEditForm(pelicula));
                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Eliminar';
                deleteButton.addEventListener('click', () => deletePelicula(pelicula.id));
                li.appendChild(editButton);
                li.appendChild(deleteButton);
                peliculasList.appendChild(li);
            });
        })
        .catch(error => console.error('Error al obtener las películas:', error));

    // Agregar una película cuando se envía el formulario
    document.getElementById('add-pelicula-form').addEventListener('submit', function(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);
        fetch('/pelicula', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(Object.fromEntries(formData))
        })
            .then(response => response.json())
            .then(data => {
                // Recargar la lista de películas después de agregar una nueva
                location.reload();
            })
            .catch(error => console.error('Error al agregar la película:', error));
    });

    // Función para mostrar el formulario de edición
    function showEditForm(pelicula) {
        const editForm = document.getElementById('edit-pelicula-form');
        editForm.style.display = 'block';
        editForm.elements['edit-titulo'].value = pelicula.titulo;
        editForm.elements['edit-director'].value = pelicula.director;
        editForm.elements['edit-año'].value = pelicula.año;
        editForm.elements['edit-genero'].value = pelicula.genero;
        editForm.elements['edit-calificacion'].value = pelicula.calificacion;
        editForm.elements['edit-id'].value = pelicula.id;
    }

    // Manejar la cancelación de la edición
    document.getElementById('cancel-edit').addEventListener('click', function(event) {
        event.preventDefault();
        const editForm = document.getElementById('edit-pelicula-form');
        editForm.style.display = 'none';
    });

    // Manejar la actualización de la película
    document.getElementById('edit-pelicula-form').addEventListener('submit', function(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);
        const id = formData.get('id');
        fetch(`/pelicula/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(Object.fromEntries(formData))
        })
            .then(response => response.json())
            .then(data => {
                // Recargar la lista de películas después de editar una película
                location.reload();
            })
            .catch(error => console.error('Error al editar la película:', error));
    });

    // Función para eliminar una película
    function deletePelicula(id) {
        if (confirm('¿Estás seguro de que quieres eliminar esta película?')) {
            fetch(`/pelicula/${id}`, {
                method: 'DELETE'
            })
                .then(response => {
                    if (response.ok) {
                        // Recargar la lista de películas después de eliminar una película
                        location.reload();
                    } else {
                        console.error('Error al eliminar la película:', response.status);
                    }
                })
                .catch(error => console.error('Error al eliminar la película:', error));
        }
    }
});
