package quarkus;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;

import java.util.List;

@Path("/pelicula")
@Transactional
public class PeliculasResource {
    @Inject
    private PeliculasRepository repo;

    @GET
    public List<Peliculas> index(){
        return repo.listAll();
    }

    @POST
    public Peliculas insert(Peliculas insertedPeliculas){
        repo.persist(insertedPeliculas);
        return insertedPeliculas;
    }

    @PUT
    @Path("/{id}")
    public Response update(@PathParam("id") Long id, Peliculas updatedPeliculas) {
        Peliculas existingPeliculas = repo.findById(id);
        if (existingPeliculas == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        existingPeliculas.setTitulo(updatedPeliculas.getTitulo());
        existingPeliculas.setDirector(updatedPeliculas.getDirector());
        existingPeliculas.setAño(updatedPeliculas.getAño());
        existingPeliculas.setGenero(updatedPeliculas.getGenero());
        existingPeliculas.setCalificacion(updatedPeliculas.getCalificacion());

        repo.persist(existingPeliculas);

        return Response.ok(existingPeliculas).build();
    }

    @DELETE
    @Path("/{id}")
    public Response delete(@PathParam("id") Long id) {
        Peliculas peliculas = repo.findById(id);
        if (peliculas == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        repo.delete(peliculas);

        return Response.ok().build();
    }

}
