package quarkus;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.util.Objects;
@Entity
public class Peliculas {

    @Id
    private Long id;
    private String titulo;
    private String director;
    private int año;
    private String genero;
    private String calificacion;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDirector(){
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(String calificacion) {
        this.calificacion = calificacion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Peliculas peliculas)) return false;
        return año == peliculas.año && Objects.equals(titulo, peliculas.titulo) && Objects.equals(director, peliculas.director) && Objects.equals(genero, peliculas.genero) && Objects.equals(calificacion, peliculas.calificacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(titulo, director, año, genero, calificacion);
    }

    @Override
    public String toString() {
        return "Pelicula{" +
                "titulo='" + titulo + '\'' +
                ", director='" + director + '\'' +
                ", año=" + año +
                ", genero='" + genero + '\'' +
                ", calificacion='" + calificacion + '\'' +
                '}';
    }
}
