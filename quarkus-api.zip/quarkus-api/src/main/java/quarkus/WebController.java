package quarkus;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;

@Path("/")
public class WebController {

    @GET
    @Produces("text/html")
    public String index() {
        return "/index.html";
    }
}
